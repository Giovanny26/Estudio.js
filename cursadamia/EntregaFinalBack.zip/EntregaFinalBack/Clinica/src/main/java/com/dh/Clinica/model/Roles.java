package com.dh.Clinica.model;

public enum Roles {
    USER,
    ADMIN
}
