package com.dh.Clinica.repository;

import com.dh.Clinica.model.Domicilio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DomicilioRepository extends JpaRepository<Domicilio, Long> {
}
